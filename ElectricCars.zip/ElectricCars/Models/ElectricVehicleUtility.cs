﻿namespace Models;

public class ElectricVehicleUtility
{
    public int ElectricCarId { get; set; }
    public ElectricCar ElectricCar { get; set; }

    public int ElectricUtilityId { get; set; }
    public ElectricUtility ElectricUtility { get; set; }
}
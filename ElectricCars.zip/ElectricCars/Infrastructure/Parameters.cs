﻿namespace Infrastructure;

public class Parameters
{
    public static string FilePath = @"D:\uni\ElectricCars\Infrastructure\Electric_Vehicle_Population_Data.csv";
    public static string ConnectionString = @"Server=DESKTOP-ENRVS12;Database=NewElectric;Trusted_Connection=True;TrustServerCertificate=True;";
}